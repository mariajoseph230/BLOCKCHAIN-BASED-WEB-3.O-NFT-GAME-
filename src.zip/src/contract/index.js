import contract from './AVAXGods.json'

export const ADDRESS = '0x860ce4f63B65CDbaB4e2f5c40EBeA0323cA48532'

// ABI is Application Binary Interface allows frontend side to call functions that was created inside smart contract
export const { abi: ABI } = contract
